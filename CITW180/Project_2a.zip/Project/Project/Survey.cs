﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project
{
    public class Survey
    {
        public int CustomerID;
        public int IncidentID;
        public int ResponseTIme;
        public int TechEfficiency;
        public int Resolution;
        public string Comments;
        public bool Contact;
        public string ContactBy;

    }
}